package wpialgs;

/**
 * A very simple Java program to check that you have installed Java correctly on your machine.
 *
 * @author Yu-Shan Sun
 * @version 1.0
 */
public class HelloWorld {

    /**
     * The main entry point to the program.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Welcome to CS 2223!");
    }

}